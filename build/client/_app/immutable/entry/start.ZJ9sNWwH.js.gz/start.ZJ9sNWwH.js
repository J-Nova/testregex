import{a as t}from"../chunks/entry.y2QgKIlI.js";export{t as start};
